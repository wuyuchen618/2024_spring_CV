1.open M11202130_CV_finalproject_stereoscopic_sbs_reconstruct_3d.ipynb
2.run all code 
3.generate output images
4.get colored point cloud result

